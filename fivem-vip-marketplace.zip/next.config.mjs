/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['placeholder.com', 'via.placeholder.com'],
    unoptimized: true,
  },
  experimental: {
    serverActions: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  webpack: (config, { isServer }) => {
    // Otimizações para o build
    if (!isServer) {
      // Não incluir react-dom no cliente
      config.externals = [...(config.externals || []), 'react-dom'];
    }
    
    // Otimizar para produção
    if (process.env.NODE_ENV === 'production') {
      // Habilitar tree-shaking
      config.optimization.usedExports = true;
    }
    
    return config;
  },
  // Configuração para domínios e subdomínios
  async rewrites() {
    return [
      {
        source: '/:path*',
        destination: '/:path*',
        has: [
          {
            type: 'host',
            value: 'centralfive.shop',
          },
        ],
      },
      {
        source: '/:path*',
        destination: '/app/:path*',
        has: [
          {
            type: 'host',
            value: 'admsapp.centralfive.shop',
          },
        ],
      },
      {
        source: '/:path*',
        destination: '/checkout/:path*',
        has: [
          {
            type: 'host',
            value: 'checkout.centralfive.shop',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
