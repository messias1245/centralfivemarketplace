import { type NextRequest, NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"

export async function middleware(req: NextRequest) {
  const { pathname, origin, host } = req.nextUrl
  const baseDomain = process.env.NEXT_PUBLIC_BASE_DOMAIN || "centralfive.shop"
  const adminDomain = process.env.NEXT_PUBLIC_ADMIN_DOMAIN || `admsapp.${baseDomain}`
  const checkoutDomain = process.env.NEXT_PUBLIC_CHECKOUT_DOMAIN || `checkout.${baseDomain}`

  // Verificar se é um subdomínio de loja
  const isStoreDomain =
    host !== baseDomain && host !== adminDomain && host !== checkoutDomain && host.endsWith(`.${baseDomain}`)

  // Redirecionar para o domínio correto com base no caminho
  if (host === baseDomain) {
    // Domínio principal
    if (pathname.startsWith("/app")) {
      return NextResponse.redirect(`https://${adminDomain}${pathname}`)
    }

    if (pathname.startsWith("/checkout")) {
      return NextResponse.redirect(`https://${checkoutDomain}${pathname.replace("/checkout", "")}`)
    }
  } else if (host === adminDomain) {
    // Domínio de admin
    if (!pathname.startsWith("/app") && pathname !== "/api/auth/signin" && !pathname.startsWith("/api/")) {
      return NextResponse.redirect(`https://${adminDomain}/app`)
    }

    // Verificar autenticação para rotas de admin
    if (pathname.startsWith("/app")) {
      const token = await getToken({ req })

      if (!token) {
        return NextResponse.redirect(`https://${adminDomain}/api/auth/signin`)
      }
    }
  } else if (host === checkoutDomain) {
    // Domínio de checkout
    // Nenhuma restrição especial, apenas garantir que não acesse rotas de admin
    if (pathname.startsWith("/app")) {
      return NextResponse.redirect(`https://${adminDomain}${pathname}`)
    }
  } else if (isStoreDomain) {
    // Subdomínio de loja
    const subdomain = host.replace(`.${baseDomain}`, "")

    // Verificar se a loja existe
    // Esta verificação pode ser feita aqui ou na página da loja

    // Redirecionar rotas de admin ou checkout para os domínios corretos
    if (pathname.startsWith("/app")) {
      return NextResponse.redirect(`https://${adminDomain}${pathname}`)
    }

    if (pathname.startsWith("/checkout")) {
      return NextResponse.redirect(`https://${checkoutDomain}${pathname.replace("/checkout", "")}?store=${subdomain}`)
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public (public files)
     */
    "/((?!_next/static|_next/image|favicon.ico|public).*)",
  ],
}
