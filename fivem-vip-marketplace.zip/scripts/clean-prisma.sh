#!/bin/bash

echo "Limpando cache do Prisma..."

# Remover diretório .prisma
rm -rf node_modules/.prisma

# Remover diretório generated
rm -rf node_modules/@prisma/client/generated

# Gerar cliente Prisma novamente
npx prisma generate

echo "Cache do Prisma limpo com sucesso!"
