#!/bin/bash

# Configurações do MySQL
DB_USER="root"
DB_PASS=""
DB_NAME="centralfive"

# Criar banco de dados
echo "Criando banco de dados $DB_NAME..."
mysql -u $DB_USER -e "CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Verificar se o banco foi criado
if [ $? -eq 0 ]; then
  echo "Banco de dados criado com sucesso!"
else
  echo "Erro ao criar banco de dados."
  exit 1
fi

# Executar migração do Prisma
echo "Executando migração do Prisma..."
npx prisma migrate deploy

# Gerar cliente Prisma
echo "Gerando cliente Prisma..."
npx prisma generate

# Inicializar dados
echo "Inicializando dados..."
ts-node scripts/init-db.ts

echo "Configuração do MySQL concluída com sucesso!"
