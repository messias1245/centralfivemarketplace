#!/bin/bash

echo "Forçando geração do Prisma client..."

# Remover diretório node_modules/.prisma se existir
if [ -d "node_modules/.prisma" ]; then
  rm -rf node_modules/.prisma
  echo "Diretório node_modules/.prisma removido."
fi

# Remover diretório node_modules/@prisma/client/generated se existir
if [ -d "node_modules/@prisma/client/generated" ]; then
  rm -rf node_modules/@prisma/client/generated
  echo "Diretório node_modules/@prisma/client/generated removido."
fi

# Gerar cliente Prisma
echo "Gerando cliente Prisma..."
npx prisma generate

echo "Cliente Prisma gerado com sucesso!"
