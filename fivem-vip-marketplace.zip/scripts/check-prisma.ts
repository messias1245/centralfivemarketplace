import { PrismaClient } from "@prisma/client"

async function main() {
  console.log("Verificando conexão com o Prisma...")

  try {
    const prisma = new PrismaClient()
    await prisma.$connect()
    console.log("Conexão com o Prisma estabelecida com sucesso!")

    // Testar uma consulta simples
    const usersCount = await prisma.user.count()
    console.log(`Número de usuários no banco de dados: ${usersCount}`)

    await prisma.$disconnect()
  } catch (error) {
    console.error("Erro ao conectar com o Prisma:", error)
    process.exit(1)
  }
}

main()
