#!/bin/bash

echo "Preparando ambiente para produção..."

# Limpar cache do Prisma
bash scripts/clean-prisma.sh

# Gerar cliente Prisma
npx prisma generate

# Usar configuração de produção
cp next.config.production.js next.config.js

echo "Ambiente preparado para produção!"
