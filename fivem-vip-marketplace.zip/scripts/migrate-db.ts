import { exec } from "child_process"
import { promisify } from "util"

const execAsync = promisify(exec)

async function main() {
  try {
    console.log("Iniciando migração do banco de dados...")

    // Executar migração do Prisma
    await execAsync("npx prisma migrate deploy")
    console.log("Migração concluída com sucesso!")

    // Gerar cliente Prisma
    await execAsync("npx prisma generate")
    console.log("Cliente Prisma gerado com sucesso!")

    // Inicializar banco de dados com dados padrão
    await execAsync("ts-node scripts/init-db.ts")

    console.log("Banco de dados configurado com sucesso!")
  } catch (error) {
    console.error("Erro ao migrar banco de dados:", error)
    process.exit(1)
  }
}

main()
