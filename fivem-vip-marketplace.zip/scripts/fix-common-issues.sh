#!/bin/bash

echo "Verificando e corrigindo problemas comuns..."

# Verificar se o Prisma está instalado corretamente
if [ ! -d "node_modules/.prisma" ]; then
  echo "Prisma não encontrado, reinstalando..."
  npm uninstall @prisma/client prisma
  npm install @prisma/client prisma
fi

# Limpar cache do Next.js
echo "Limpando cache do Next.js..."
rm -rf .next

# Limpar cache do Prisma
echo "Limpando cache do Prisma..."
bash scripts/clean-prisma.sh

# Verificar conexão com o banco de dados
echo "Verificando conexão com o banco de dados..."
npx ts-node scripts/check-prisma.ts

echo "Verificação concluída!"
