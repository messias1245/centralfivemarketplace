import { PrismaClient } from "@prisma/client"
import { hash } from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  try {
    // Criar usuário admin
    const adminExists = await prisma.user.findUnique({
      where: {
        email: "admin@centralfive.shop",
      },
    })

    if (!adminExists) {
      const hashedPassword = await hash("admin123", 10)

      await prisma.user.create({
        data: {
          name: "Administrador",
          email: "admin@centralfive.shop",
          password: hashedPassword,
          role: "ADMIN",
        },
      })

      console.log("Usuário admin criado com sucesso!")
    }

    // Criar categorias padrão
    const categoriesCount = await prisma.category.count()

    if (categoriesCount === 0) {
      await prisma.category.createMany({
        data: [
          { name: "VIP", description: "Pacotes VIP para servidores" },
          { name: "Scripts", description: "Scripts e recursos para servidores" },
          { name: "Serviços", description: "Serviços de desenvolvimento e suporte" },
        ],
      })

      console.log("Categorias padrão criadas com sucesso!")
    }

    console.log("Banco de dados inicializado com sucesso!")
  } catch (error) {
    console.error("Erro ao inicializar banco de dados:", error)
  } finally {
    await prisma.$disconnect()
  }
}

main()
