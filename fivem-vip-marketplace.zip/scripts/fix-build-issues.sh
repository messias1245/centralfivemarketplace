#!/bin/bash

echo "Verificando e corrigindo problemas comuns de build..."

# Verificar se o Prisma está instalado corretamente
if [ ! -d "node_modules/.prisma" ]; then
  echo "Prisma não encontrado, reinstalando..."
  npm uninstall @prisma/client prisma
  npm install @prisma/client prisma
fi

# Limpar cache do Next.js
echo "Limpando cache do Next.js..."
rm -rf .next

# Forçar geração do Prisma client
echo "Forçando geração do Prisma client..."
bash scripts/force-generate-prisma.sh

# Verificar se o arquivo .env.local existe
if [ ! -f ".env.local" ]; then
  echo "Arquivo .env.local não encontrado, criando..."
  cp .env.example .env.local
fi

# Verificar se o arquivo .env.production existe
if [ ! -f ".env.production" ]; then
  echo "Arquivo .env.production não encontrado, criando..."
  cp .env.example .env.production
fi

echo "Verificação concluída!"
