"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

const formSchema = z.object({
  amount: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 20, {
    message: "O valor mínimo para saque é R$ 20,00",
  }),
  bank_code: z.string().min(3, "Código do banco inválido"),
  account_number: z.string().min(5, "Número da conta inválido"),
  branch_code: z.string().min(3, "Número da agência inválido"),
  account_holder_name: z.string().min(3, "Nome do titular inválido"),
  account_type: z.enum(["checking", "savings"], {
    message: "Selecione o tipo de conta",
  }),
  tax_id: z.string().min(11, "CPF/CNPJ inválido"),
})

type FormValues = z.infer<typeof formSchema>

export default function WithdrawalPage() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: "",
      bank_code: "",
      account_number: "",
      branch_code: "",
      account_holder_name: "",
      account_type: "checking",
      tax_id: "",
    },
  })

  const onSubmit = async (data: FormValues) => {
    setIsLoading(true)
    try {
      const response = await fetch("/cliente/app/dashboard/api/saque", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          amount: Math.round(Number.parseFloat(data.amount) * 100), // Converter para centavos
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Erro ao processar saque")
      }

      toast({
        title: "Saque solicitado com sucesso",
        description: "Seu saque foi registrado e será processado em breve.",
        variant: "default",
      })

      reset()
    } catch (error) {
      console.error("Erro ao solicitar saque:", error)
      toast({
        title: "Erro ao solicitar saque",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao processar sua solicitação",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Solicitar Saque</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Dados Bancários</CardTitle>
            <CardDescription>Informe os dados para receber seu saque</CardDescription>
          </CardHeader>
          <CardContent>
            <form id="withdrawal-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Valor (R$)</Label>
                <Input id="amount" placeholder="0,00" {...register("amount")} />
                {errors.amount && <p className="text-sm text-red-500">{errors.amount.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="bank_code">Código do Banco</Label>
                <Input id="bank_code" placeholder="Ex: 341 (Itaú)" {...register("bank_code")} />
                {errors.bank_code && <p className="text-sm text-red-500">{errors.bank_code.message}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="branch_code">Agência</Label>
                  <Input id="branch_code" placeholder="Sem dígito" {...register("branch_code")} />
                  {errors.branch_code && <p className="text-sm text-red-500">{errors.branch_code.message}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="account_number">Conta</Label>
                  <Input id="account_number" placeholder="Com dígito" {...register("account_number")} />
                  {errors.account_number && <p className="text-sm text-red-500">{errors.account_number.message}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="account_type">Tipo de Conta</Label>
                <Select defaultValue="checking" {...register("account_type")}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo de conta" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="checking">Conta Corrente</SelectItem>
                    <SelectItem value="savings">Conta Poupança</SelectItem>
                  </SelectContent>
                </Select>
                {errors.account_type && <p className="text-sm text-red-500">{errors.account_type.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="account_holder_name">Nome do Titular</Label>
                <Input
                  id="account_holder_name"
                  placeholder="Nome completo conforme banco"
                  {...register("account_holder_name")}
                />
                {errors.account_holder_name && (
                  <p className="text-sm text-red-500">{errors.account_holder_name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="tax_id">CPF/CNPJ do Titular</Label>
                <Input id="tax_id" placeholder="Apenas números" {...register("tax_id")} />
                {errors.tax_id && <p className="text-sm text-red-500">{errors.tax_id.message}</p>}
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button type="submit" form="withdrawal-form" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processando...
                </>
              ) : (
                "Solicitar Saque"
              )}
            </Button>
          </CardFooter>
        </Card>

        <WithdrawalHistory />
      </div>
    </div>
  )
}

function WithdrawalHistory() {
  const [withdrawals, setWithdrawals] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchWithdrawals() {
      try {
        const response = await fetch("/cliente/app/dashboard/api/saque")

        if (!response.ok) {
          throw new Error(`Erro na requisição: ${response.status}`)
        }

        const data = await response.json()
        setWithdrawals(data.withdrawals || [])
      } catch (error) {
        console.error("Erro ao buscar histórico de saques:", error)
        setError("Não foi possível carregar o histórico de saques")
      } finally {
        setIsLoading(false)
      }
    }

    fetchWithdrawals()
  }, [])

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Saques</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-red-500">{error}</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Histórico de Saques</CardTitle>
        <CardDescription>Acompanhe o status dos seus saques</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : withdrawals.length === 0 ? (
          <p className="text-center py-6 text-muted-foreground">Nenhum saque solicitado ainda</p>
        ) : (
          <div className="space-y-4">
            {withdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium">R$ {(withdrawal.amount / 100).toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">
                      Banco: {withdrawal.bankCode} - Ag: {withdrawal.branchCode} - Conta: {withdrawal.accountNumber}
                    </p>
                  </div>
                  <div>
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        withdrawal.status === "COMPLETED"
                          ? "bg-green-100 text-green-800"
                          : withdrawal.status === "FAILED"
                            ? "bg-red-100 text-red-800"
                            : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {withdrawal.status === "PENDING"
                        ? "Pendente"
                        : withdrawal.status === "PROCESSING"
                          ? "Em processamento"
                          : withdrawal.status === "COMPLETED"
                            ? "Concluído"
                            : "Falhou"}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Solicitado em {new Date(withdrawal.createdAt).toLocaleDateString("pt-BR")} às{" "}
                  {new Date(withdrawal.createdAt).toLocaleTimeString("pt-BR")}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
