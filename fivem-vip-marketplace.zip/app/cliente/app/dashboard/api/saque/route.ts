import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { z } from "zod"

const withdrawalSchema = z.object({
  amount: z.number().min(1),
  bank_code: z.string().min(3),
  account_number: z.string().min(5),
  branch_code: z.string().min(3),
  account_holder_name: z.string().min(3),
  account_type: z.enum(["checking", "savings"]),
  tax_id: z.string().min(11),
})

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const body = await req.json()
    const validationResult = withdrawalSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json({ error: "Dados inválidos", details: validationResult.error.format() }, { status: 400 })
    }

    const data = validationResult.data

    // Verificar se o usuário tem saldo suficiente
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, balance: true },
    })

    if (!user) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    if (user.balance < data.amount) {
      return NextResponse.json({ error: "Saldo insuficiente" }, { status: 400 })
    }

    // Registrar o saque no banco de dados
    const withdrawal = await prisma.withdrawal.create({
      data: {
        userId: user.id,
        amount: data.amount,
        status: "PENDING",
        bankCode: data.bank_code,
        accountNumber: data.account_number,
        branchCode: data.branch_code,
        accountHolderName: data.account_holder_name,
        accountType: data.account_type,
        taxId: data.tax_id,
      },
    })

    // Atualizar o saldo do usuário
    await prisma.user.update({
      where: { id: user.id },
      data: { balance: { decrement: data.amount } },
    })

    // Registrar a transação
    await prisma.transaction.create({
      data: {
        userId: user.id,
        amount: -data.amount,
        type: "WITHDRAWAL",
        description: `Saque para ${data.bank_code} - Ag: ${data.branch_code} - Conta: ${data.account_number}`,
        status: "COMPLETED",
        referenceId: withdrawal.id,
      },
    })

    return NextResponse.json({
      success: true,
      withdrawal: {
        id: withdrawal.id,
        amount: withdrawal.amount,
        status: withdrawal.status,
        createdAt: withdrawal.createdAt,
      },
    })
  } catch (error) {
    console.error("Erro ao processar saque:", error)
    return NextResponse.json({ error: "Erro ao processar saque" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Não autorizado", withdrawals: [] }, { status: 401 })
    }

    // Buscar histórico de saques do usuário
    const withdrawals = await prisma.withdrawal.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        amount: true,
        status: true,
        createdAt: true,
        bankCode: true,
        accountNumber: true,
        branchCode: true,
      },
    })

    return NextResponse.json({ withdrawals })
  } catch (error) {
    console.error("Erro ao buscar saques:", error)
    return NextResponse.json({ error: "Erro ao buscar saques", withdrawals: [] }, { status: 500 })
  }
}
