import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { prisma } from "@/lib/prisma"
import { headers } from "next/headers"

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = headers().get("stripe-signature") as string

  if (!signature) {
    return NextResponse.json({ error: "Assinatura Stripe ausente" }, { status: 400 })
  }

  let event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    console.error("Erro ao verificar assinatura webhook:", err)
    return NextResponse.json({ error: "Assinatura inválida" }, { status: 400 })
  }

  try {
    switch (event.type) {
      case "payment_intent.succeeded":
        await handlePaymentIntentSucceeded(event.data.object)
        break

      case "payment_intent.payment_failed":
        await handlePaymentIntentFailed(event.data.object)
        break
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Erro ao processar webhook:", error)
    return NextResponse.json({ error: "Erro ao processar webhook" }, { status: 500 })
  }
}

async function handlePaymentIntentSucceeded(paymentIntent: any) {
  const { cartId, store, userId } = paymentIntent.metadata

  if (!cartId) {
    console.error("CartId não encontrado no metadata do PaymentIntent")
    return
  }

  // Buscar o carrinho
  const cart = await prisma.cart.findUnique({
    where: { id: cartId },
    include: {
      items: {
        include: {
          product: true,
        },
      },
    },
  })

  if (!cart) {
    console.error("Carrinho não encontrado:", cartId)
    return
  }

  // Criar pedido
  const order = await prisma.order.create({
    data: {
      userId: userId !== "anonymous" ? userId : undefined,
      total: paymentIntent.amount,
      status: "PAID",
      paymentMethod: paymentIntent.metadata.paymentMethod,
      paymentIntentId: paymentIntent.id,
      store: store || undefined,
      items: {
        create: cart.items.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
          name: item.product.name,
        })),
      },
    },
  })

  // Processar entrega de VIPs ou produtos digitais
  for (const item of cart.items) {
    if (item.product.type === "VIP") {
      // Entregar VIP
      await prisma.vip.create({
        data: {
          userId: userId !== "anonymous" ? userId : undefined,
          serverId: item.product.serverId!,
          name: item.product.name,
          identifier: "", // Será preenchido pelo usuário
          expiresAt: new Date(Date.now() + (item.product.duration || 30) * 24 * 60 * 60 * 1000),
          orderId: order.id,
        },
      })
    }
  }

  // Limpar o carrinho
  await prisma.cartItem.deleteMany({
    where: { cartId },
  })

  await prisma.cart.update({
    where: { id: cartId },
    data: {
      items: {
        deleteMany: {},
      },
      paymentIntentId: null,
    },
  })
}

async function handlePaymentIntentFailed(paymentIntent: any) {
  // Registrar falha de pagamento
  console.log("Pagamento falhou:", paymentIntent.id)

  // Atualizar status do carrinho se necessário
  if (paymentIntent.metadata.cartId) {
    await prisma.cart.update({
      where: { id: paymentIntent.metadata.cartId },
      data: {
        paymentStatus: "FAILED",
      },
    })
  }
}
