import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { cookies } from "next/headers"

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const cookieStore = cookies()
    const sessionId = cookieStore.get("cart-session")?.value || ""

    // Buscar carrinho existente
    let cart

    if (session?.user?.id) {
      // Usuário logado - buscar por userId
      cart = await prisma.cart.findFirst({
        where: {
          userId: session.user.id,
          paymentStatus: { not: "COMPLETED" },
        },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      })
    } else if (sessionId) {
      // Usuário não logado - buscar por sessionId
      cart = await prisma.cart.findFirst({
        where: {
          sessionId,
          paymentStatus: { not: "COMPLETED" },
        },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      })
    }

    // Se não existir carrinho, criar um novo
    if (!cart) {
      const newCart = {
        userId: session?.user?.id || null,
        sessionId: sessionId || `session_${Date.now()}`,
      }

      cart = await prisma.cart.create({
        data: newCart,
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      })

      // Se não havia sessionId, definir um novo
      if (!sessionId) {
        cookieStore.set("cart-session", cart.sessionId, {
          path: "/",
          maxAge: 60 * 60 * 24 * 30, // 30 dias
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
        })
      }
    }

    // Calcular subtotal
    const subtotal = cart.items.reduce((acc, item) => acc + item.price * item.quantity, 0)

    return NextResponse.json({
      cart: {
        ...cart,
        subtotal,
        total: subtotal,
      },
    })
  } catch (error) {
    console.error("Erro ao buscar carrinho:", error)
    return NextResponse.json({ error: "Erro ao buscar carrinho" }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const cookieStore = cookies()
    const sessionId = cookieStore.get("cart-session")?.value || `session_${Date.now()}`
    const body = await req.json()

    const { productId, quantity = 1 } = body

    if (!productId) {
      return NextResponse.json({ error: "ID do produto é obrigatório" }, { status: 400 })
    }

    // Buscar produto
    const product = await prisma.product.findUnique({
      where: { id: productId },
    })

    if (!product) {
      return NextResponse.json({ error: "Produto não encontrado" }, { status: 404 })
    }

    // Buscar ou criar carrinho
    let cart = await prisma.cart.findFirst({
      where: {
        OR: [
          { userId: session?.user?.id || null, paymentStatus: { not: "COMPLETED" } },
          { sessionId, paymentStatus: { not: "COMPLETED" } },
        ],
      },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    })

    if (!cart) {
      cart = await prisma.cart.create({
        data: {
          userId: session?.user?.id || null,
          sessionId,
        },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      })

      // Definir cookie de sessão
      cookieStore.set("cart-session", sessionId, {
        path: "/",
        maxAge: 60 * 60 * 24 * 30, // 30 dias
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
      })
    }

    // Verificar se o produto já está no carrinho
    const existingItem = cart.items.find((item) => item.productId === productId)

    if (existingItem) {
      // Atualizar quantidade
      await prisma.cartItem.update({
        where: { id: existingItem.id },
        data: { quantity: existingItem.quantity + quantity },
      })
    } else {
      // Adicionar novo item
      await prisma.cartItem.create({
        data: {
          cartId: cart.id,
          productId,
          quantity,
          price: product.price,
        },
      })
    }

    // Buscar carrinho atualizado
    const updatedCart = await prisma.cart.findUnique({
      where: { id: cart.id },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    })

    // Calcular subtotal
    const subtotal = updatedCart.items.reduce((acc, item) => acc + item.price * item.quantity, 0)

    return NextResponse.json({
      cart: {
        ...updatedCart,
        subtotal,
        total: subtotal,
      },
    })
  } catch (error) {
    console.error("Erro ao adicionar item ao carrinho:", error)
    return NextResponse.json({ error: "Erro ao adicionar item ao carrinho" }, { status: 500 })
  }
}
