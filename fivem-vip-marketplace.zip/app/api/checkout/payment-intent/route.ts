import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { stripe, CARD_FEE_PERCENTAGE } from "@/lib/stripe"
import { z } from "zod"

const paymentIntentSchema = z.object({
  cartId: z.string(),
  paymentMethod: z.enum(["card", "pix"]),
  installments: z.number().min(1).max(12).default(1),
  store: z.string().optional(),
})

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const body = await req.json()

    const validationResult = paymentIntentSchema.safeParse(body)

    if (!validationResult.success) {
      return NextResponse.json({ error: "Dados inválidos", details: validationResult.error.format() }, { status: 400 })
    }

    const { cartId, paymentMethod, installments, store } = validationResult.data

    // Buscar o carrinho
    const cart = await prisma.cart.findUnique({
      where: { id: cartId },
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    })

    if (!cart) {
      return NextResponse.json({ error: "Carrinho não encontrado" }, { status: 404 })
    }

    // Calcular o total
    const subtotal = cart.items.reduce((acc, item) => acc + item.price * item.quantity, 0)

    // Adicionar taxa para cartão de crédito
    let total = subtotal
    if (paymentMethod === "card") {
      const fee = Math.round(subtotal * (CARD_FEE_PERCENTAGE / 100))
      total += fee

      // Adicionar juros para parcelamento (configurável pelo painel)
      if (installments > 1) {
        // Buscar taxa de parcelamento do banco de dados
        // Por enquanto, usamos um valor fixo de exemplo: 1.5% ao mês
        const installmentFee = 1.5
        const installmentTotal = total * Math.pow(1 + installmentFee / 100, installments - 1)
        total = Math.round(installmentTotal)
      }
    }

    // Criar ou atualizar o intent de pagamento
    let paymentIntent

    if (cart.paymentIntentId) {
      // Atualizar intent existente
      paymentIntent = await stripe.paymentIntents.update(cart.paymentIntentId, {
        amount: total,
        payment_method_types: paymentMethod === "pix" ? ["pix"] : ["card"],
        metadata: {
          cartId,
          paymentMethod,
          installments: installments.toString(),
          store: store || "",
        },
      })
    } else {
      // Criar novo intent
      paymentIntent = await stripe.paymentIntents.create({
        amount: total,
        currency: "brl",
        payment_method_types: paymentMethod === "pix" ? ["pix"] : ["card"],
        metadata: {
          cartId,
          paymentMethod,
          installments: installments.toString(),
          store: store || "",
          userId: session?.user?.id || "anonymous",
        },
      })

      // Atualizar o carrinho com o ID do intent
      await prisma.cart.update({
        where: { id: cartId },
        data: { paymentIntentId: paymentIntent.id },
      })
    }

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      total,
      fee: total - subtotal,
    })
  } catch (error) {
    console.error("Erro ao criar intent de pagamento:", error)
    return NextResponse.json({ error: "Erro ao processar pagamento" }, { status: 500 })
  }
}
