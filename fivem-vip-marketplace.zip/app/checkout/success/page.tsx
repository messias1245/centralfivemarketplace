"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Loader2, CheckCircle } from "lucide-react"

export default function CheckoutSuccessPage() {
  const searchParams = useSearchParams()
  const paymentIntentId = searchParams.get("payment_intent")
  const [order, setOrder] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchOrder() {
      if (!paymentIntentId) {
        setError("ID de pagamento não encontrado")
        setLoading(false)
        return
      }

      try {
        const response = await fetch(`/api/orders/by-payment/${paymentIntentId}`)

        if (!response.ok) {
          throw new Error("Erro ao buscar pedido")
        }

        const data = await response.json()
        setOrder(data.order)
      } catch (error) {
        console.error("Erro:", error)
        setError("Não foi possível carregar os detalhes do pedido")
      } finally {
        setLoading(false)
      }
    }

    fetchOrder()
  }, [paymentIntentId])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto py-10 text-center">
        <h1 className="text-2xl font-bold mb-4">Erro</h1>
        <p className="mb-6">{error}</p>
        <Button asChild>
          <a href="/">Voltar para a loja</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <div className="max-w-md mx-auto text-center mb-8">
        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold mb-2">Pagamento Confirmado!</h1>
        <p className="text-muted-foreground">Seu pedido foi processado com sucesso.</p>
      </div>

      {order && (
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Detalhes do Pedido</CardTitle>
            <CardDescription>Pedido #{order.id}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Itens</h3>
                <div className="space-y-2">
                  {order.items.map((item: any) => (
                    <div key={item.id} className="flex justify-between">
                      <span>
                        {item.quantity}x {item.name}
                      </span>
                      <span>R$ {((item.price * item.quantity) / 100).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>R$ {(order.total / 100).toFixed(2)}</span>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Método de Pagamento</h3>
                <p>{order.paymentMethod === "card" ? "Cartão de Crédito" : "PIX"}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button asChild>
              <a href="/area-cliente">Acessar Minha Conta</a>
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
