"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { loadStripe } from "@stripe/stripe-js"
import { Elements } from "@stripe/react-stripe-js"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, CreditCard, QrCode } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js"

// Carregue o Stripe.js
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default function CheckoutPage() {
  const searchParams = useSearchParams()
  const storeParam = searchParams.get("store")
  const [cart, setCart] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [paymentMethod, setPaymentMethod] = useState<"card" | "pix">("pix")
  const [installments, setInstallments] = useState(1)
  const [clientSecret, setClientSecret] = useState("")
  const [processing, setProcessing] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    async function fetchCart() {
      try {
        const response = await fetch("/api/checkout/cart")
        if (!response.ok) {
          throw new Error("Erro ao carregar carrinho")
        }

        const data = await response.json()
        setCart(data.cart)

        // Iniciar intent de pagamento
        const paymentResponse = await fetch("/api/checkout/payment-intent", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            cartId: data.cart.id,
            paymentMethod: "pix",
            installments: 1,
            store: storeParam || undefined,
          }),
        })

        if (!paymentResponse.ok) {
          throw new Error("Erro ao iniciar pagamento")
        }

        const paymentData = await paymentResponse.json()
        setClientSecret(paymentData.clientSecret)
      } catch (error) {
        console.error("Erro:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar o carrinho",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchCart()
  }, [storeParam, toast])

  const handlePaymentMethodChange = async (method: "card" | "pix") => {
    setPaymentMethod(method)
    setProcessing(true)

    try {
      const response = await fetch("/api/checkout/payment-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          cartId: cart.id,
          paymentMethod: method,
          installments: method === "card" ? installments : 1,
          store: storeParam || undefined,
        }),
      })

      if (!response.ok) {
        throw new Error("Erro ao atualizar método de pagamento")
      }

      const data = await response.json()
      setClientSecret(data.clientSecret)
    } catch (error) {
      console.error("Erro:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o método de pagamento",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  const handleInstallmentsChange = async (value: number) => {
    setInstallments(value)

    if (paymentMethod !== "card") return

    setProcessing(true)

    try {
      const response = await fetch("/api/checkout/payment-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          cartId: cart.id,
          paymentMethod: "card",
          installments: value,
          store: storeParam || undefined,
        }),
      })

      if (!response.ok) {
        throw new Error("Erro ao atualizar parcelamento")
      }

      const data = await response.json()
      setClientSecret(data.clientSecret)
    } catch (error) {
      console.error("Erro:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o parcelamento",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!cart || cart.items.length === 0) {
    return (
      <div className="container mx-auto py-10 text-center">
        <h1 className="text-2xl font-bold mb-4">Seu carrinho está vazio</h1>
        <p className="mb-6">Adicione produtos ao carrinho para continuar com a compra.</p>
        <Button asChild>
          <a href="/">Voltar para a loja</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Finalizar Compra</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Método de Pagamento</CardTitle>
              <CardDescription>Escolha como deseja pagar</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="pix" onValueChange={(value) => handlePaymentMethodChange(value as "card" | "pix")}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="pix" disabled={processing}>
                    <QrCode className="mr-2 h-4 w-4" />
                    PIX
                  </TabsTrigger>
                  <TabsTrigger value="card" disabled={processing}>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Cartão de Crédito
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="pix">
                  <div className="space-y-4 py-4">
                    <div className="rounded-lg bg-muted p-4 text-center">
                      <p className="text-sm text-muted-foreground mb-2">Pagamento instantâneo via PIX</p>
                      <p className="font-medium">Sem taxas adicionais</p>
                    </div>

                    {clientSecret && (
                      <Elements stripe={stripePromise} options={{ clientSecret }}>
                        <PixPayment clientSecret={clientSecret} />
                      </Elements>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="card">
                  <div className="space-y-4 py-4">
                    <div className="rounded-lg bg-muted p-4 text-center">
                      <p className="text-sm text-muted-foreground mb-2">Taxa de 3,99% para pagamentos com cartão</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="installments">Parcelamento</Label>
                      <select
                        id="installments"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        value={installments}
                        onChange={(e) => handleInstallmentsChange(Number.parseInt(e.target.value))}
                        disabled={processing}
                      >
                        {Array.from({ length: 12 }, (_, i) => i + 1).map((num) => (
                          <option key={num} value={num}>
                            {num}x {num === 1 ? "à vista" : `de R$ ${((cart.total * (1 + 0.0399)) / num).toFixed(2)}`}
                            {num > 1 ? ` (total: R$ ${(cart.total * (1 + 0.0399)).toFixed(2)})` : ""}
                          </option>
                        ))}
                      </select>
                    </div>

                    {clientSecret && (
                      <Elements stripe={stripePromise} options={{ clientSecret }}>
                        <CardPayment clientSecret={clientSecret} installments={installments} cart={cart} />
                      </Elements>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Resumo do Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cart.items.map((item: any) => (
                  <div key={item.id} className="flex justify-between">
                    <span>
                      {item.quantity}x {item.product.name}
                    </span>
                    <span>R$ {((item.price * item.quantity) / 100).toFixed(2)}</span>
                  </div>
                ))}

                <div className="border-t pt-4">
                  <div className="flex justify-between font-medium">
                    <span>Subtotal</span>
                    <span>R$ {(cart.subtotal / 100).toFixed(2)}</span>
                  </div>

                  {paymentMethod === "card" && (
                    <div className="flex justify-between text-sm text-muted-foreground mt-2">
                      <span>Taxa de pagamento (3,99%)</span>
                      <span>R$ {((cart.subtotal * 0.0399) / 100).toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between font-bold text-lg mt-4">
                    <span>Total</span>
                    <span>
                      R$ {(paymentMethod === "card" ? (cart.subtotal * 1.0399) / 100 : cart.subtotal / 100).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function PixPayment({ clientSecret }: { clientSecret: string }) {
  const [qrCode, setQrCode] = useState<string | null>(null)
  const [qrCodeText, setQrCodeText] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [expiresAt, setExpiresAt] = useState<Date | null>(null)
  const [timeLeft, setTimeLeft] = useState<string>("")
  const stripe = useStripe()
  const { toast } = useToast()

  useEffect(() => {
    async function getPixInfo() {
      if (!stripe || !clientSecret) return

      try {
        const result = await stripe.retrievePaymentIntent(clientSecret)

        if (result.error) {
          throw new Error(result.error.message)
        }

        if (result.paymentIntent?.next_action?.display_bank_transfer_instructions) {
          const instructions = result.paymentIntent.next_action.display_bank_transfer_instructions

          setQrCode(instructions.hosted_instructions_url)
          setQrCodeText(instructions.financial_address)

          // Definir expiração para 10 minutos a partir de agora
          const expires = new Date()
          expires.setMinutes(expires.getMinutes() + 10)
          setExpiresAt(expires)
        }
      } catch (error) {
        console.error("Erro ao obter QR Code PIX:", error)
        toast({
          title: "Erro",
          description: "Não foi possível gerar o QR Code PIX",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    getPixInfo()
  }, [stripe, clientSecret, toast])

  useEffect(() => {
    if (!expiresAt) return

    const interval = setInterval(() => {
      const now = new Date()
      const diff = expiresAt.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeLeft("Expirado")
        clearInterval(interval)
        return
      }

      const minutes = Math.floor(diff / 60000)
      const seconds = Math.floor((diff % 60000) / 1000)

      setTimeLeft(`${minutes}:${seconds.toString().padStart(2, "0")}`)
    }, 1000)

    return () => clearInterval(interval)
  }, [expiresAt])

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center space-y-4">
      {qrCode && (
        <>
          <div className="text-center mb-4">
            <p className="font-medium">Escaneie o QR Code para pagar</p>
            <p className="text-sm text-muted-foreground">O QR Code expira em {timeLeft}</p>
          </div>

          <div className="border p-4 rounded-lg">
            <img src={qrCode || "/placeholder.svg"} alt="QR Code PIX" className="w-64 h-64" />
          </div>

          {qrCodeText && (
            <div className="w-full">
              <p className="text-sm text-center mb-2">Ou copie o código PIX:</p>
              <div className="flex">
                <Input value={qrCodeText} readOnly className="flex-1" />
                <Button
                  variant="outline"
                  className="ml-2"
                  onClick={() => {
                    navigator.clipboard.writeText(qrCodeText)
                    toast({
                      title: "Código copiado",
                      description: "O código PIX foi copiado para a área de transferência",
                    })
                  }}
                >
                  Copiar
                </Button>
              </div>
            </div>
          )}

          <div className="text-center mt-4">
            <p className="text-sm">Após o pagamento, você será redirecionado automaticamente.</p>
            <p className="text-sm text-muted-foreground">Não feche esta página até concluir o pagamento.</p>
          </div>
        </>
      )}
    </div>
  )
}

function CardPayment({ clientSecret, installments, cart }: { clientSecret: string; installments: number; cart: any }) {
  const stripe = useStripe()
  const elements = useElements()
  const [error, setError] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)
  const [cardComplete, setCardComplete] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!stripe || !elements) {
      return
    }

    const cardElement = elements.getElement(CardElement)

    if (!cardElement) {
      return
    }

    setProcessing(true)
    setError(null)

    try {
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
          billing_details: {
            // Você pode adicionar detalhes de cobrança aqui se necessário
          },
        },
        payment_method_options: {
          card: {
            installments: {
              enabled: installments > 1,
              plan:
                installments > 1
                  ? {
                      type: "fixed_count",
                      count: installments,
                    }
                  : undefined,
            },
          },
        },
      })

      if (error) {
        setError(error.message || "Ocorreu um erro ao processar o pagamento")
        toast({
          title: "Erro no pagamento",
          description: error.message || "Ocorreu um erro ao processar o pagamento",
          variant: "destructive",
        })
      } else if (paymentIntent.status === "succeeded") {
        toast({
          title: "Pagamento confirmado",
          description: "Seu pagamento foi processado com sucesso",
        })

        // Redirecionar para página de sucesso
        window.location.href = `/checkout/success?payment_intent=${paymentIntent.id}`
      }
    } catch (err) {
      console.error("Erro ao processar pagamento:", err)
      setError("Ocorreu um erro ao processar o pagamento")
      toast({
        title: "Erro no pagamento",
        description: "Ocorreu um erro ao processar o pagamento",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="card-element">Dados do Cartão</Label>
          <div className="border rounded-md p-3">
            <CardElement
              id="card-element"
              options={{
                style: {
                  base: {
                    fontSize: "16px",
                    color: "#424770",
                    "::placeholder": {
                      color: "#aab7c4",
                    },
                  },
                  invalid: {
                    color: "#9e2146",
                  },
                },
              }}
              onChange={(e) => setCardComplete(e.complete)}
            />
          </div>
          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>

        <Button type="submit" disabled={!stripe || processing || !cardComplete} className="w-full">
          {processing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processando...
            </>
          ) : (
            `Pagar R$ ${((cart?.total || 0) / 100).toFixed(2)}`
          )}
        </Button>
      </div>
    </form>
  )
}
