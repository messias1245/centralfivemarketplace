// Este é um stub do Prisma para usar durante o build
// Será substituído pelo Prisma real após o deploy

export const prisma = {
  user: {
    findUnique: async () => null,
    update: async () => ({}),
  },
  passwordReset: {
    findUnique: async () => null,
    upsert: async () => ({}),
    create: async () => ({}),
    delete: async () => ({}),
  },
}

export default prisma
