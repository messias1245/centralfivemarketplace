if (!process.env.CLOUDFLARE_API_TOKEN) {
  throw new Error("CLOUDFLARE_API_TOKEN não está definido")
}

if (!process.env.CLOUDFLARE_ZONE_ID) {
  throw new Error("CLOUDFLARE_ZONE_ID não está definido")
}

const API_TOKEN = process.env.CLOUDFLARE_API_TOKEN
const ZONE_ID = process.env.CLOUDFLARE_ZONE_ID
const BASE_URL = "https://api.cloudflare.com/client/v4"

export async function createSubdomain(
  subdomain: string,
  baseDomain: string = process.env.NEXT_PUBLIC_BASE_DOMAIN || "centralfive.shop",
) {
  const fullDomain = `${subdomain}.${baseDomain}`

  try {
    const response = await fetch(`${BASE_URL}/zones/${ZONE_ID}/dns_records`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${API_TOKEN}`,
      },
      body: JSON.stringify({
        type: "CNAME",
        name: subdomain,
        content: baseDomain,
        ttl: 1,
        proxied: true,
      }),
    })

    const data = await response.json()

    if (!data.success) {
      throw new Error(data.errors?.[0]?.message || "Erro ao criar subdomínio")
    }

    return {
      success: true,
      record: data.result,
    }
  } catch (error) {
    console.error("Erro ao criar subdomínio:", error)
    throw error
  }
}

export async function deleteSubdomain(
  subdomain: string,
  baseDomain: string = process.env.NEXT_PUBLIC_BASE_DOMAIN || "centralfive.shop",
) {
  try {
    // Primeiro, precisamos encontrar o registro
    const recordId = await getSubdomainRecordId(subdomain)

    if (!recordId) {
      throw new Error("Subdomínio não encontrado")
    }

    const response = await fetch(`${BASE_URL}/zones/${ZONE_ID}/dns_records/${recordId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${API_TOKEN}`,
      },
    })

    const data = await response.json()

    if (!data.success) {
      throw new Error(data.errors?.[0]?.message || "Erro ao excluir subdomínio")
    }

    return {
      success: true,
    }
  } catch (error) {
    console.error("Erro ao excluir subdomínio:", error)
    throw error
  }
}

export async function checkSubdomainAvailability(
  subdomain: string,
  baseDomain: string = process.env.NEXT_PUBLIC_BASE_DOMAIN || "centralfive.shop",
) {
  try {
    const recordId = await getSubdomainRecordId(subdomain)

    return {
      available: !recordId,
    }
  } catch (error) {
    console.error("Erro ao verificar disponibilidade do subdomínio:", error)
    throw error
  }
}

async function getSubdomainRecordId(subdomain: string) {
  try {
    const response = await fetch(
      `${BASE_URL}/zones/${ZONE_ID}/dns_records?name=${subdomain}.${process.env.NEXT_PUBLIC_BASE_DOMAIN || "centralfive.shop"}`,
      {
        headers: {
          Authorization: `Bearer ${API_TOKEN}`,
        },
      },
    )

    const data = await response.json()

    if (!data.success) {
      throw new Error(data.errors?.[0]?.message || "Erro ao buscar subdomínio")
    }

    if (data.result.length === 0) {
      return null
    }

    return data.result[0].id
  } catch (error) {
    console.error("Erro ao buscar ID do registro de subdomínio:", error)
    throw error
  }
}
