// Durante o build, usamos o stub do Prisma
// Em produção, usamos o Prisma real

import prismaStub from "./prisma-stub"

// Verificar se estamos em ambiente de build
const isBuildTime = process.env.NODE_ENV === "production" && process.env.NEXT_PHASE === "phase-production-build"

// Exportar o stub durante o build
export const prisma = isBuildTime ? prismaStub : require("@prisma/client").PrismaClient()

export default prisma
