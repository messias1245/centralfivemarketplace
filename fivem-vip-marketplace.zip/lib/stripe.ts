import Stripe from "stripe"

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY não está definido")
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
  appInfo: {
    name: "CentralFive Marketplace",
    version: "1.0.0",
  },
})

export const CARD_FEE_PERCENTAGE = 3.99
export const PIX_FEE_PERCENTAGE = 0

export const PLANS = {
  BASIC: {
    name: "Básico",
    price: 2000, // R$20,00 em centavos
    description: "Melhor para quem começa e ainda não fatura um valor fixo mensalmente",
    monthlyLimit: 220000, // R$2.200,00 em centavos
    paymentMethodFee: 33, // R$0,33 em centavos
  },
  ADVANCED: {
    name: "Avançado",
    price: 4500, // R$45,00 em centavos
    description: "Para negócios em crescimento com volume maior de vendas",
    monthlyLimit: 450000, // R$4.500,00 em centavos
    paymentMethodFee: 0, // 0% de taxa
  },
}

export async function createPaymentIntent(
  amount: number,
  paymentMethod: "card" | "pix",
  installments = 1,
  metadata: Record<string, string> = {},
) {
  let totalAmount = amount

  // Adiciona taxa para cartão de crédito
  if (paymentMethod === "card") {
    const fee = Math.round(amount * (CARD_FEE_PERCENTAGE / 100))
    totalAmount += fee

    // Adiciona juros para parcelamento (configurável pelo painel)
    if (installments > 1) {
      // Buscar taxa de parcelamento do banco de dados
      // Por enquanto, usamos um valor fixo de exemplo: 1.5% ao mês
      const installmentFee = 1.5
      const installmentTotal = totalAmount * Math.pow(1 + installmentFee / 100, installments - 1)
      totalAmount = Math.round(installmentTotal)
    }
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount: totalAmount,
    currency: "brl",
    payment_method_types: paymentMethod === "pix" ? ["pix"] : ["card"],
    metadata: {
      ...metadata,
      payment_method: paymentMethod,
      installments: installments.toString(),
      original_amount: amount.toString(),
    },
  })

  return {
    clientSecret: paymentIntent.client_secret,
    totalAmount,
    fee: totalAmount - amount,
  }
}

export async function createCheckoutSession(
  items: Array<{ price: string; quantity: number }>,
  successUrl: string,
  cancelUrl: string,
  metadata: Record<string, string> = {},
) {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card", "pix"],
    line_items: items,
    mode: "payment",
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata,
  })

  return session
}

export async function createPlan(planType: "BASIC" | "ADVANCED", customerId: string, paymentMethodId: string) {
  const plan = PLANS[planType]

  const subscription = await stripe.subscriptions.create({
    customer: customerId,
    items: [
      {
        price_data: {
          currency: "brl",
          product_data: {
            name: `Plano ${plan.name}`,
            description: plan.description,
          },
          unit_amount: plan.price,
          recurring: {
            interval: "month",
          },
        },
      },
    ],
    default_payment_method: paymentMethodId,
    metadata: {
      plan_type: planType,
      monthly_limit: plan.monthlyLimit.toString(),
      payment_method_fee: plan.paymentMethodFee.toString(),
    },
  })

  return subscription
}

export async function createWithdrawal(
  amount: number,
  bankAccount: {
    bank_code: string
    account_number: string
    branch_code: string
    account_holder_name: string
    account_type: "checking" | "savings"
    tax_id: string
  },
  metadata: Record<string, string> = {},
) {
  // Stripe não suporta saques diretamente para contas bancárias brasileiras
  // Esta é uma implementação simulada para integração com API externa

  // Na implementação real, você precisaria usar a API do seu banco ou
  // um serviço como Pagar.me, Asaas, etc. para processar o saque

  // Registramos o saque no banco de dados para processamento manual ou via webhook

  return {
    id: `withdrawal_${Date.now()}`,
    amount,
    status: "pending",
    bank_account: bankAccount,
    created_at: new Date().toISOString(),
    metadata,
  }
}
