# FiveM VIP Marketplace

## Configuração do MySQL

### Pré-requisitos
- MySQL Server instalado
- phpMyAdmin (opcional, mas recomendado)

### Passos para configuração

1. **Criar banco de dados**

   Acesse o phpMyAdmin e crie um novo banco de dados chamado `centralfive` com collation `utf8mb4_unicode_ci`.

   Ou execute o seguinte comando no terminal:

   \`\`\`bash
   mysql -u root -p -e "CREATE DATABASE centralfive CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
   \`\`\`

2. **Configurar variáveis de ambiente**

   Edite o arquivo `.env.local` e configure a URL de conexão do MySQL:

   \`\`\`
   DATABASE_URL="mysql://root:senha@localhost:3306/centralfive"
   \`\`\`

   Substitua `senha` pela senha do seu usuário MySQL. Se não houver senha, deixe em branco: `mysql://root:@localhost:3306/centralfive`

3. **Executar script de configuração**

   \`\`\`bash
   npm run setup-db
   \`\`\`

   Este script irá:
   - Criar o banco de dados (se ainda não existir)
   - Executar as migrações do Prisma
   - Gerar o cliente Prisma
   - Inicializar dados padrão (usuário admin, categorias, etc.)

4. **Iniciar o servidor de desenvolvimento**

   \`\`\`bash
   npm run dev
   \`\`\`

## Acesso ao sistema

- **URL:** http://localhost:3000
- **Admin:** http://localhost:3000/app
- **Checkout:** http://localhost:3000/checkout

### Credenciais de acesso (padrão)

- **Email:** admin@centralfive.shop
- **Senha:** admin123

## Comandos úteis

- **Iniciar servidor de desenvolvimento:** `npm run dev`
- **Construir para produção:** `npm run build`
- **Iniciar servidor de produção:** `npm run start`
- **Executar migrações:** `npm run migrate`
- **Inicializar dados:** `npm run seed`
\`\`\`

Vamos criar um arquivo de instruções para configurar o phpMyAdmin:
