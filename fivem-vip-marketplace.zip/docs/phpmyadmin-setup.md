# Configuração do phpMyAdmin

## Instalação no Windows (XAMPP)

1. Baixe e instale o XAMPP: https://www.apachefriends.org/download.html
2. Inicie o Apache e o MySQL no painel de controle do XAMPP
3. Acesse o phpMyAdmin em: http://localhost/phpmyadmin

## Instalação no Ubuntu

\`\`\`bash
sudo apt update
sudo apt install phpmyadmin php-mbstring php-zip php-gd php-json php-curl
\`\`\`

Durante a instalação:
- Selecione "apache2" quando solicitado
- Escolha "Yes" para configurar o banco de dados com dbconfig-common
- Defina uma senha para o usuário phpmyadmin

Acesse o phpMyAdmin em: http://localhost/phpmyadmin

## Criação do banco de dados

1. Faça login no phpMyAdmin
2. Clique em "Novo" no painel lateral esquerdo
3. Digite "centralfive" como nome do banco de dados
4. Selecione "utf8mb4_unicode_ci" como collation
5. Clique em "Criar"

## Configuração de usuário (opcional)

Se você quiser criar um usuário específico para o projeto:

1. Vá para a aba "Contas de utilizadores"
2. Clique em "Adicionar conta de utilizador"
3. Preencha o nome de utilizador e senha
4. Em "Base de dados para utilizador", selecione "Conceder todos os privilégios ao banco de dados nomeado como:"
5. Digite "centralfive" no campo
6. Clique em "Executar"

## Atualização do arquivo .env.local

Atualize o arquivo `.env.local` com as credenciais do banco de dados:

\`\`\`
DATABASE_URL="mysql://username:password@localhost:3306/centralfive"
\`\`\`

Substitua `username` e `password` pelas credenciais que você configurou.
\`\`\`

Vamos criar um arquivo de instruções para executar o projeto:
