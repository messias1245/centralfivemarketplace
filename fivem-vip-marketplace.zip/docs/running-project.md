# Executando o Projeto

## Desenvolvimento

1. **Instalar dependências**

   \`\`\`bash
   npm install
   \`\`\`

2. **Configurar banco de dados**

   Siga as instruções em `README.md` para configurar o MySQL.

3. **Iniciar servidor de desenvolvimento**

   \`\`\`bash
   npm run dev
   \`\`\`

   O servidor estará disponível em: http://localhost:3000

## Produção

1. **Construir para produção**

   \`\`\`bash
   npm run build
   \`\`\`

2. **Iniciar servidor de produção**

   \`\`\`bash
   npm run start
   \`\`\`

## Usando o Docker (opcional)

1. **Construir a imagem Docker**

   \`\`\`bash
   docker build -t fivem-vip-marketplace .
   \`\`\`

2. **Executar o contêiner**

   \`\`\`bash
   docker run -p 3000:3000 -e DATABASE_URL="mysql://user:password@host:3306/centralfive" fivem-vip-marketplace
   \`\`\`

   Substitua `user`, `password` e `host` pelas credenciais corretas do seu banco de dados MySQL.

## Usando o Portainer

1. **Adicionar Stack no Portainer**

   - Acesse o Portainer
   - Vá para "Stacks" e clique em "Add stack"
   - Dê um nome como "fivem-marketplace"
   - Cole o seguinte docker-compose:

   \`\`\`yaml
   version: '3'
   services:
     app:
       image: fivem-vip-marketplace:latest
       ports:
         - "3000:3000"
       environment:
         - DATABASE_URL=mysql://user:password@mysql:3306/centralfive
         - NEXTAUTH_SECRET=your_nextauth_secret
         - NEXTAUTH_URL=https://centralfive.shop
         - STRIPE_SECRET_KEY=your_stripe_secret_key
         - NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
       restart: always
     
     mysql:
       image: mysql:8.0
       ports:
         - "3306:3306"
       environment:
         - MYSQL_ROOT_PASSWORD=root_password
         - MYSQL_DATABASE=centralfive
         - MYSQL_USER=user
         - MYSQL_PASSWORD=password
       volumes:
         - mysql_data:/var/lib/mysql
       restart: always
     
     phpmyadmin:
       image: phpmyadmin/phpmyadmin
       ports:
         - "8080:80"
       environment:
         - PMA_HOST=mysql
         - PMA_USER=root
         - PMA_PASSWORD=root_password
       restart: always

   volumes:
     mysql_data:
   \`\`\`

   - Substitua as variáveis de ambiente pelos valores corretos
   - Clique em "Deploy the stack"

2. **Acessar o aplicativo**

   - O aplicativo estará disponível em: http://seu-servidor:3000
   - O phpMyAdmin estará disponível em: http://seu-servidor:8080
\`\`\`

Vamos criar um Dockerfile para facilitar a implantação:

```dockerfile file="Dockerfile"
FROM node:18-alpine AS base

# Instalar dependências necessárias
RUN apk add --no-cache libc6-compat

# Definir diretório de trabalho
WORKDIR /app

# Instalar dependências
FROM base AS deps
COPY package.json package-lock.json* ./
RUN npm ci

# Construir a aplicação
FROM base AS builder
COPY --from=deps /app/node_modules ./node_modules
COPY . .

# Gerar cliente Prisma
RUN npx prisma generate

# Construir aplicação
RUN npm run build

# Configurar para produção
FROM base AS runner
ENV NODE_ENV production

# Criar usuário não-root
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs
USER nextjs

# Copiar arquivos necessários
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
COPY --from=builder /app/prisma ./prisma
COPY --from=builder /app/node_modules/.prisma ./node_modules/.prisma

# Expor porta
EXPOSE 3000

# Definir variáveis de ambiente
ENV PORT 3000
ENV HOSTNAME "0.0.0.0"

# Comando para iniciar a aplicação
CMD ["node", "server.js"]
