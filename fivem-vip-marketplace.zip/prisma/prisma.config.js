/**
 * Configuração do Prisma para garantir que o cliente seja gerado corretamente
 */
module.exports = {
  // Configurações para garantir que o Prisma funcione corretamente
  engineType: "binary",
  previewFeatures: [],
  // Outras configurações podem ser adicionadas conforme necessário
}
